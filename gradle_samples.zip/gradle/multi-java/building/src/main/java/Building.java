/**
 * A Building always needs a front door.
 */
public class Building {
    private final Door frontDoor = new Door();
    private final Window pictureWindow = new Window();
}