/**
 * Everyone needs a window, right?
 */
public class Window
{
}