/**
 * Yep, it's a class alright.
 */
public class Door
{
    private final Window windowInDoor = new Window();
}