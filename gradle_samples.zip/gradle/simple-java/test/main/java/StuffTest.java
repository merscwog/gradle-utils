import org.junit.Test;

public class StuffTest
{
    @Test
    public void myTest()
    {
        new Stuff();
    }
}