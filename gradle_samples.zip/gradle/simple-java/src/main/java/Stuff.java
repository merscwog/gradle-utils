/**
 * Stuff class. 
 */
public class Stuff
{
    public static void main(String[] args)
    {
        System.out.println("----->  Wow! A main method!  <-----");
    }
}